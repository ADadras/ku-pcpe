# Reconstructing KU-PCPE with KU-PCP

1. Obtain KU-PCP through its original distribution and accept its terms.
2. Set `KUPCP_ROOT` to the directory containing `train_img/` and `test_img/`.
3. Resolve `single_annotator_train` records under
   `$KUPCP_ROOT/train_img/` and `expert_test` records under
   `$KUPCP_ROOT/test_img/`.
4. Keep the train and test filename namespaces separate. The same filename
   stem can refer to different images in the two splits.
5. From the KU-PCPE release root, run:

   ```bash
   KUPCP_ROOT=/path/to/KU-PCP python -I evaluate_smoke_test.py
   ```

The script verifies the package checksums, all annotation and consensus mask
links, split counts, task identities, PNG dimensions, and each referenced
KU-PCP image when `KUPCP_ROOT` is set.

KU-PCPE does not redistribute or relicense KU-PCP photographs. `image_id` and
`image_file` are split-local reconstruction keys only.


Verification dependency: install `Pillow==11.3.0` in a fresh virtual environment before running `python -I evaluate_smoke_test.py`. The validator decodes all binary masks, checks pixel-exact PNG round trips and metadata area/dimensions, reconstructs both consensus targets, and validates the 846/481 workflow counts.
