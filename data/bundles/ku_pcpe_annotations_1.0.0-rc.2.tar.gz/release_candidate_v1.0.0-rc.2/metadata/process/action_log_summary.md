# Annotation Action-Log Summary

Aggregate process metadata only. Raw timestamps, annotator identifiers, export paths, local paths, and runtime fields are not included.

| Statistic | Single-annotator train | Expert test |
| --- | ---: | ---: |
| Tasks with logs | 4,093 | 1,327 |
| Median actions / task | 15 | 6 |
| Action-count IQR | 9-26 | 4-11 |
| Segment toggle | 84.0% | 89.8% |
| Dynamic segment addition | 31.9% | 28.3% |
| Manual refinement | 15.1% | 16.1% |
| Split operation | 5.7% | 4.7% |
| Preference-score update | 100.0% | 100.0% |
