# Annotation asset scope

This bundle contains the evaluator's annotation layout, individual binary masks, consensus masks, modality ratings and protocol metadata. The primary KU-PCPE dataset download additionally provides complete study metadata for all four annotators. Source photographs and model weights are excluded. Annotation assets are licensed under CC BY 4.0.

Workflow categories in this supporting bundle derive from one logged expert pass and yield the earlier 846/481 task grouping. The paper's main workflow analysis instead uses all three experts and the complete dataset metadata, yielding disjoint groups of 615/712 tasks. Ordered event timelines and individual action counts are supplied in the primary dataset download. Retained records do not reconstruct discarded drafts or every later mask revision. See the repository's complete-study metadata guide for definitions and commands.
