# Dataset card

KU-PCPE contains positive image-label grounding tasks for Horizontal,
Vertical, Diagonal, Curved, Triangle, Rule of thirds, Center, Symmetric, and
Pattern. A binary mask marks the visible regions selected as support for a
label already judged applicable in KU-PCP. Masks may contain objects, object
parts, disconnected regions, background, or negative space. Abstract lines
and axes are not rasterized as region targets.

The training split contains 4,093 tasks from 3,169 images and one annotator.
The expert test split contains 1,327 tasks from 1,073 images, three anonymous
expert masks per task, and strict and ambiguity-aware consensus targets.

The masks are subjective judgments of photographic structure, not identity,
demographic, or sensitive-attribute labels. Workflow metadata is included only
to describe how the annotation interface was used. The release excludes
annotator identities, timestamps, absolute paths, raw geometry payloads, and
runtime metadata. Source photographs are not redistributed.

Known limitations include proposal-assisted collection, one-annotator training
supervision, positive-only queries, and exploratory modality ratings with
modest agreement. Benchmark reports should identify the target view and
include human agreement for context.


Verification dependency: install `Pillow==11.3.0` in a fresh virtual environment before running `python -I evaluate_smoke_test.py`. The validator decodes all binary masks, checks pixel-exact PNG round trips and metadata area/dimensions, reconstructs both consensus targets, and validates the 846/481 workflow counts.


Maintenance contact: Armin Dadras, adadras@cvl.tuwien.ac.at. Bundle version 1.0.0-rc.2.
