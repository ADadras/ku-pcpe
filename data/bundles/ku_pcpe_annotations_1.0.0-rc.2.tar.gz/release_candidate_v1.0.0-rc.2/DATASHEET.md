# Datasheet for KU-PCPE

## Motivation

KU-PCPE supports research on grounding photographic composition labels in the
visible regions people use as evidence. It extends KU-PCP with one human region
representation across all nine classes.

## Composition

- 4,093 positive training tasks from 3,169 KU-PCP train images;
- 1,327 positive test tasks from 1,073 KU-PCP test images;
- one training mask and three expert masks per respective task;
- strict and ambiguity-aware consensus masks for every test task;
- exploratory segment-versus-line ratings and workflow categories and aggregate summaries.

The release contains no source photographs and no negative image-label tasks.

## Collection

Annotators received one image and one applicable KU-PCP label. They selected
and, when needed, refined visible regions that supported the queried
composition. Candidate regions were an editing aid. The three test experts
worked independently and did not see one another's masks.

## Preprocessing

Masks are stored as binary PNG files at the dimensions recorded in each JSONL
entry. Strict consensus is the pixelwise majority of the three expert masks.
The ambiguity-aware target aligns complementary partition choices before
forming a majority. Individual masks are retained so users can evaluate either
view.

## Uses and limitations

The intended use is conditional grounding after a composition label has been
judged applicable. The dataset is not designed for identity inference,
demographic analysis, or negative-label rejection. Important limitations are
the positive-only task, one-annotator training split, proposal-assisted
collection, subjective masks, and modest agreement for exploratory modality
ratings.

## Distribution and maintenance

KU-PCPE is distributed as derived annotations and split-local identifiers.
Users must obtain KU-PCP independently and follow its original terms. Package
integrity is recorded in `checksums.csv`; reconstruction and verification are
described in `RECONSTRUCTION.md`. Corrections should preserve task identifiers
and be documented by release version.


Verification dependency: install `Pillow==11.3.0` in a fresh virtual environment before running `python -I evaluate_smoke_test.py`. The validator decodes all binary masks, checks pixel-exact PNG round trips and metadata area/dimensions, reconstructs both consensus targets, and validates the 846/481 workflow counts.


Maintenance contact: Armin Dadras, adadras@cvl.tuwien.ac.at. Bundle version 1.0.0-rc.2.
