"""Validate a KU-PCPE release using only its own bundle plus optional KU-PCP."""
import csv, hashlib, io, json, os
from pathlib import Path
from PIL import Image, ImageChops
ROOT=Path(__file__).resolve().parent
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
    return h.hexdigest()
def jsonl(p): return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def mask(p):
    with Image.open(p) as image:
        assert image.mode=='L',(p,'Expected lossless 8-bit grayscale')
        image.load(); a=image.copy()
    hist=a.histogram(); assert hist[0]+hist[255]==a.width*a.height,(p,'Nonbinary mask')
    return a
def area(a): return a.histogram()[255]
def dice(a,b):
    denominator=area(a)+area(b)
    return 2*area(ImageChops.multiply(a,b))/denominator if denominator else 1.
def majority(a,b,c):
    return ImageChops.lighter(ImageChops.lighter(ImageChops.multiply(a,b),ImageChops.multiply(a,c)),ImageChops.multiply(b,c))
def run():
    rows=list(csv.DictReader((ROOT/'checksums.csv').open()))
    manifest=list(csv.DictReader((ROOT/'file_manifest.csv').open()))
    expected={r['path'] for r in rows}
    assert len(rows)==len(expected)==len(manifest)
    assert expected=={r['path'] for r in manifest}
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}-{'checksums.csv','file_manifest.csv'}
    assert actual==expected,dict(unindexed=sorted(actual-expected),missing=sorted(expected-actual))
    for row in rows:
        p=ROOT/row['path']; assert p.resolve().is_relative_to(ROOT.resolve())
        assert p.stat().st_size==int(row['bytes']) and sha(p)==row['sha256'],p
    bundles=[ROOT/'annotations/single_annotator_train']+[ROOT/f'annotations/expert_test/expert_0{i}' for i in range(1,4)]
    maps=[]; identities=[]; names=[]
    source=Path(os.environ['KUPCP_ROOT']) if os.environ.get('KUPCP_ROOT') else None
    for index,bundle in enumerate(bundles):
        records=jsonl(bundle/'annotations.jsonl'); table={r['task_id']:r for r in records}
        assert len(table)==len(records)==(4093 if index==0 else 1327)
        assert len({r['class_id'] for r in records})==9
        maps.append(table); names.append({r['image_file'] for r in records})
        for r in records:
            a=mask(bundle/r['mask_path']); assert a.size==(int(r['width']),int(r['height']))
            assert area(a)==int(r['area_px'])>0
            out=io.BytesIO(); a.save(out,format='PNG'); out.seek(0)
            with Image.open(out) as image: b=image.copy()
            assert a.tobytes()==b.tobytes()
            identities.append(dice(a,b))
            if source:
                path=source/('train_img' if index==0 else 'test_img')/r['image_file']
                with Image.open(path) as image: assert image.size==a.size
    assert len(names[0])==3169 and all(len(s)==1073 for s in names[1:])
    assert set(maps[1])==set(maps[2])==set(maps[3])
    assert not set(maps[0])&set(maps[1])
    consensus=list(csv.DictReader((ROOT/'consensus/manifest.csv').open()))
    assert len(consensus)==1327 and {r['task_id'] for r in consensus}==set(maps[1])
    for row in consensus:
        masks=[mask(bundles[i]/maps[i][row['task_id']]['mask_path']) for i in range(1,4)]
        strict=majority(*masks); aligned=[masks[0]]
        for a in masks[1:]:
            inv=ImageChops.invert(a)
            aligned.append(inv if dice(inv,masks[0])>dice(a,masks[0]) else a)
        for key,expected_mask in [('strict_mask',strict),('ambiguity_aware_mask',majority(*aligned))]:
            saved=mask(ROOT/row[key]); assert saved.size==expected_mask.size
            assert saved.tobytes()==expected_mask.tobytes(),(row['task_id'],key)
    workflow=list(csv.DictReader((ROOT/'metadata/process/workflow_by_task.csv').open()))
    test=[r for r in workflow if r['split']=='expert_test']
    assert len(test)==1327 and {r['task_id'] for r in test}==set(maps[1])
    assert sum(r['workflow']=='initial_regions' for r in test)==846
    assert sum(r['workflow']=='edited_refined' for r in test)==481
    result=dict(status='PASS',annotation_masks=len(identities),train_tasks=4093,test_tasks=1327,
                consensus_masks=2654,checksummed_files=len(rows),min_roundtrip_dice=min(identities),
                mean_roundtrip_dice=sum(identities)/len(identities),source_image_dimensions_checked=source is not None)
    print(json.dumps(result,sort_keys=True))
    print(f"SMOKE TEST PASSED: 4093 train tasks; 1327 expert-test tasks; identity Dice={result['mean_roundtrip_dice']:.6f}")
if __name__=='__main__': run()
