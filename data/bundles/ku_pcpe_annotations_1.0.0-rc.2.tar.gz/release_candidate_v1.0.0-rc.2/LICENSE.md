# License

The KU-PCPE annotation layer, including annotation records, binary masks,
consensus masks, metadata, schemas, and documentation in this package, is
licensed under the Creative Commons Attribution 4.0 International License
(CC BY 4.0): https://creativecommons.org/licenses/by/4.0/.

This license does not cover KU-PCP photographs or other third-party material.
The photographs are not included in this package. Users must obtain KU-PCP
separately and comply with its original distribution terms.
