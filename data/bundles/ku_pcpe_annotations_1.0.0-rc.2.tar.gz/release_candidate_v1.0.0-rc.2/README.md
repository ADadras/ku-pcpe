# KU-PCP Elements (KU-PCPE)

KU-PCPE is a label-conditioned region-evidence annotation layer for the nine
KU-PCP photographic composition classes. It contains derived annotations and
split-local KU-PCP identifiers, but no source photographs.

## Contents

- `annotations/`: one training bundle and three pseudonymous expert-test bundles;
- `consensus/`: strict and ambiguity-aware test targets;
- `metadata/`: exploratory modality ratings and workflow categories and aggregate summaries;
- `schemas/`: annotation and workflow field definitions;
- `benchmark_proposal_config.json`: the fixed proposal benchmark settings;
- `split_manifest.csv`: split, image, task, and annotator counts;
- `file_manifest.csv` and `checksums.csv`: complete package inventory;
- `DATASET_CARD.md` and `DATASHEET.md`: scope, construction, and limitations;
- `RECONSTRUCTION.md`: instructions for joining annotations to KU-PCP;
- `evaluate_smoke_test.py`: integrity and reconstruction checks.

Run the following from the release root:

```bash
KUPCP_ROOT=/path/to/KU-PCP python -I evaluate_smoke_test.py
```

The final line should be:

```text
SMOKE TEST PASSED: 4093 train tasks; 1327 expert-test tasks; identity Dice=1.000000
```

The annotation layer is licensed separately from the KU-PCP photographs. See
`LICENSE.md`, `RECONSTRUCTION.md`, and the original KU-PCP terms.


Verification dependency: install `Pillow==11.3.0` in a fresh virtual environment before running `python -I evaluate_smoke_test.py`. The validator decodes all binary masks, checks pixel-exact PNG round trips and metadata area/dimensions, reconstructs both consensus targets, and validates the 846/481 workflow counts.
