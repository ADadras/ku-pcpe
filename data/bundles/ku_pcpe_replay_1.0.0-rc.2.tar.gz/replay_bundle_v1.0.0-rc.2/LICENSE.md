Derived prediction/selection annotations are licensed under CC BY 4.0. Credit the KU-PCPE paper and original KU-PCP. No upstream model weights or photos are licensed by this bundle.
