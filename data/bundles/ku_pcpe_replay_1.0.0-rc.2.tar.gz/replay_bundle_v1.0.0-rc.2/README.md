# Saved-prediction bundle 1.0.0-rc.2

Permitted derived binary predictions, original SAM2.1 proposals, and fixed VLM responses/IDs for numerical re-evaluation. Source photographs, renderings containing photographs, weights, credentials, internal paths and action sequences are excluded. Original candidate order is preserved. The training accumulation order is explicit to preserve float32 arithmetic. No VLM inference is claimed.
