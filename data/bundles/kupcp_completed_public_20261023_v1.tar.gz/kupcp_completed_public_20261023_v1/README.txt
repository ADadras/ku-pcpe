KUPCP completed annotation sets: public export

Includes every current submitted task for annotator/split sets that cover the
entire source split: three test (val) sets and one train set in this release.
The database was read in one read-only transaction. Partial sets are excluded.

Start with annotations.csv and tool_usage_by_annotator.csv. Use
tool_usage_by_task.csv and tool_usage_by_class.csv for detailed analysis.
tool_timeline.csv answers which tool was used at which relative time and stage.
Times are five-second bins within observed clock segments, capped at 30 minutes;
no calendar times, cross-task ordering or raw cursor coordinates are included.

SAM usage is separated into automatic on-demand segmentation, advanced prompts,
and final precomputed/dynamic regions. These are observed interaction counts,
not exact inference request counts, GPU time or active working time. Pen/lasso
edits and other recorded controls are counted separately. See data_dictionary.json.

annotations.jsonl.gz includes final and component region RLE masks plus safe
metadata. PNGs and COCO masks reproduce the latest submitted masks exactly.
Application RLE is row-major; COCO segmentation is column-major uncompressed RLE.
Original dataset images are not bundled. Dataset split versions are corrected
from split identity; source train payloads had an incorrect test version label.

Original participant identifiers, calendar times, participant preferences, free
text, raw event metadata, filesystem paths and archive owner metadata are removed.
The private source snapshot and ID mapping are stored separately and are not
part of this archive. This is a pseudonymised release, not a guarantee of
irreversible anonymity: the cohort is small and contains a unique train rater.

validation.json records coverage, mask and telemetry checks; checksums.sha256
covers all other public files. No source database or previous export was changed.
